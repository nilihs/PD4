package com.myapplicationdev.android.c302_p07_ps;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;


public class ViewContactDetailsActivity extends AppCompatActivity {

    private EditText etFirstName, etLastName, etMobile;
    private Button btnUpdate, btnDelete;
    private int contactId;
    private AsyncHttpClient myClient = new AsyncHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_contact_details);

        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        etMobile = findViewById(R.id.etMobile);

        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);

        Intent intent = getIntent();
        contactId = intent.getIntExtra("contact_id", -1);

        //TODO: call getContactDetails.php with the id as a parameter
        myClient.get("http://10.0.2.2/C302_P07/getContactDetails.php?id=" + contactId, new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                try {
                    Log.i("JSON Results: ", response.toString());
                    String firstName = response.getString("firstname");
                    String lastName = response.getString("lastname");
                    String mobile = response.getString("mobile");

                    etFirstName.setText(firstName);
                    etLastName.setText(lastName);
                    etMobile.setText(mobile);

                    Contact contact = new Contact(contactId, firstName, lastName, mobile);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
                //TODO: set the text fields with the data retrieved

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnUpdateOnClick(v);
            }
        });

        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnDeleteOnClick(v);
            }
        });
    }//end onCreate

    
    private void btnUpdateOnClick(View v) {
		//TODO: retrieve the updated text fields and set as parameters to be passed to updateContact.php
        RequestParams params = new RequestParams();
        params.put("id",contactId);
        params.put("firstname", etFirstName.getText().toString());
        params.put("lastname", etLastName.getText().toString());
        params.put("mobile", etMobile.getText().toString());

        myClient.post("http://10.0.2.2/C302_P07/updateContact.php", params, new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                try {
                    Log.i("JSON Results: ", response.toString());
                    Toast.makeText(getApplicationContext(),
                            response.getString("message"), Toast.LENGTH_LONG).show();
                    finish();
                }
                catch(JSONException e){
                    e.printStackTrace();
                }
            }
        });

    }//end btnUpdateOnClick

    private void btnDeleteOnClick(View v) {
		//TODO: retrieve the id and set as parameters to be passed to deleteContact.php
        RequestParams params = new RequestParams();
        params.put("id", contactId);

        myClient.post("http://10.0.2.2/C302_P07/deleteContact.php", params, new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                try {
                    Log.i("JSON Results: ", response.toString());
                    Toast.makeText(getApplicationContext(),
                            response.getString("message"), Toast.LENGTH_LONG).show();
                    finish();
                }
                catch(JSONException e){
                    e.printStackTrace();
                }
            }
        });
    }//end btnDeleteOnClick

}//end class